package com.example.trashclssifydemo.activities;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.example.trashclssifydemo.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class searchTrash extends BaseActivity {

    private ListView listView;
    private EditText editText;
    private ImageView back_button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature( Window.FEATURE_NO_TITLE );

        //不显示系统的标题栏
        getWindow().setFlags( WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN );
        setContentView(R.layout.activity_search_trash);
        editText=(EditText)findViewById(R.id.input);
        listView=(ListView)findViewById(R.id.searchAns);
        back_button=(ImageView)findViewById(R.id.back);
        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(searchTrash.this,Fenle.class);
                startActivity(intent);
            }
        });
        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if(actionId == EditorInfo.IME_ACTION_SEARCH){
                    String key=editText.getText().toString().trim();
                    if(key.length()==0){
                        return false;
                    }
                    List<String> list1=new ArrayList<>();
                    List<String> list2=new ArrayList<>();
                    List<String> list3=new ArrayList<>();
                    List<String> list4=new ArrayList<>();
                    for(String str:Fenle.re_trash){
                        if(str.startsWith(key)){
                            list1.add(str);
                        }
                    }
                    for(String str:Fenle.un_trash){
                        if(str.startsWith(key)){
                            list2.add(str);
                        }
                    }
                    for(String str:Fenle.chuyu_trash){
                        if(str.startsWith(key)){
                            list3.add(str);
                        }
                    }
                    for(String str:Fenle.qita_trash){
                        if(str.startsWith(key)){
                            list4.add(str);
                        }
                    }
                     ArrayList<HashMap<String, Object>> listItem = new ArrayList<HashMap<String,     Object>>();
                    for(int i=0;i<list1.size();i++)
                    {
                        HashMap<String, Object> map = new HashMap<String, Object>();
                        map.put("recycle", R.drawable.recycle);//加入图片
                        map.put("trash_name", list1.get(i));
                        listItem.add(map);
                    }
                    for(int i=0;i<list2.size();i++)
                    {
                        HashMap<String, Object> map = new HashMap<String, Object>();
                        map.put("recycle", R.drawable.youhai);//加入图片
                        map.put("trash_name", list2.get(i));
                        listItem.add(map);
                    }
                    for(int i=0;i<list3.size();i++)
                    {
                        HashMap<String, Object> map = new HashMap<String, Object>();
                        map.put("recycle", R.drawable.chuyuphoto);//加入图片
                        map.put("trash_name", list3.get(i));
                        listItem.add(map);
                    }
                    for(int i=0;i<list4.size();i++)
                    {
                        HashMap<String, Object> map = new HashMap<String, Object>();
                        map.put("recycle", R.drawable.qita);//加入图片
                        map.put("trash_name", list4.get(i));
                        listItem.add(map);
                    }

                   SimpleAdapter simpleAdapter = new SimpleAdapter(searchTrash.this,listItem,//需要绑定的数据
                            R.layout.show_trash,
                            new String[] {"recycle","trash_name"},
                            new int[] {R.id.recycle,R.id.trash_name});
                    listView.setAdapter(simpleAdapter);
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) {
                        imm.hideSoftInputFromWindow(back_button.getWindowToken(), 0);
                    }
                }
                return false;    }
        });
    }


}
