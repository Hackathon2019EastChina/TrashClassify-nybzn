package com.example.trashclssifydemo.activities;

import android.app.Activity;
import android.content.Intent;
import android.support.annotation.IdRes;
import android.view.View;
import android.widget.ImageView;

import com.example.trashclssifydemo.R;


public class BaseActivity extends Activity {

    ImageView fenlei;
    ImageView shibie;
    ImageView set;


    protected <T extends View> T fd(@IdRes int id){
        return findViewById(id);
    }

    protected void initBars(boolean isShowShibie,boolean isShowFenlei,boolean isShowSet){
        fenlei=fd(R.id.fenlei);
        shibie=fd(R.id.shibie);
        set=fd(R.id.set);
        if(isShowFenlei){
            fenlei.setImageResource(R.drawable.pressed_fenlei);
        }else{
            fenlei.setImageResource(R.drawable.fenlei);
        }
        if(isShowShibie){
            shibie.setImageResource(R.drawable.pressed_shibie);
        }else{
            shibie.setImageResource(R.drawable.shibie);
        }
        if(isShowSet){
            set.setImageResource(R.drawable.pressed_set);
        }else{
            set.setImageResource(R.drawable.set);
        }
        fenlei.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toFenlei();
            }
        });
        shibie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toMain();
            }
        });
        set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toSet();
            }
        });
    }

    private void toFenlei(){
        Intent intent=new Intent(this, Fenle.class);
        startActivity(intent);
        finish();
    }

    private void toMain(){
        Intent intent=new Intent(this, MainActivity.class) ;
        startActivity(intent);
        finish();
    }

    private void toSet(){
        Intent intent=new Intent(this, set.class);
        startActivity(intent);
        finish();
    }
}
