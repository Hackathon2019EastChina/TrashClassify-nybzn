package com.example.trashclssifydemo.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;

import com.example.trashclssifydemo.R;

public class set extends BaseActivity {

    FrameLayout frameLayout;
    FrameLayout concernningUs;
    FrameLayout contactus;
    FrameLayout share;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature( Window.FEATURE_NO_TITLE );

        //不显示系统的标题栏
        getWindow().setFlags( WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN );
        setContentView(R.layout.activity_set);
        frameLayout=(FrameLayout)findViewById(R.id.locationChange);
        frameLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toLocate();
            }
        });
        concernningUs=(FrameLayout)findViewById(R.id.aboutUs);
        contactus=(FrameLayout)findViewById(R.id.contactUs);
        concernningUs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toAboutUS();
            }
        });
        contactus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(set.this,contactus.class);
                startActivity(intent);
            }
        });
        initBars(false,false,true);
    }

    private void toLocate(){
        Intent intent=new Intent(this,locate.class);
        startActivity(intent);

    }

    private void toAboutUS(){
        Intent intent=new Intent(this,aboutUs.class);
        startActivity(intent);

    }

}
