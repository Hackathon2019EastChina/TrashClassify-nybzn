package com.example.trashclssifydemo.activities;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.trashclssifydemo.R;


import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;

import static android.net.sip.SipErrorCode.TIME_OUT;
import static android.provider.CallLog.Calls.CONTENT_TYPE;
import static android.provider.Telephony.Mms.Part.CHARSET;

public class show extends BaseActivity {


    Button back;
    ImageView imageView;
    private Uri imageUri;
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature( Window.FEATURE_NO_TITLE );

        //不显示系统的标题栏
        getWindow().setFlags( WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN );
        setContentView(R.layout.activity_show);
        textView=(TextView)findViewById(R.id.result);
        back = (Button) findViewById(R.id.back);
        imageView = (ImageView) findViewById(R.id.pic);
        Intent intent = getIntent();

//            URL url = new URL("https://southcentralus.api.cognitive.microsoft.com/customvision/v3.0/Prediction/e0ab0c11-8fd1-4d0c-986a-31a49d38fb9c/classify/iterations/Iteration1/image");
//            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//            conn.setDoInput(true);
//            conn.setDoOutput(true);
//            conn.setUseCaches(false);
//
//            conn.setRequestProperty("Prediction-Key", "");  //设置编码
//            conn.setRequestProperty("Content-Type", "application/octet-stream");
//            conn.setRequestProperty("Prediction-key", "{2a57fc3aafa5b7af415a03b2d}");
            if (intent != null) {
                imageUri = intent.getParcelableExtra("uri");
                Bitmap bitmap = null;
                try {
                    bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(imageUri));
//                    byte[] imageBytes = Bitmap2Bytes(bitmap);
//                    DataOutputStream dsDataOutputStream = new DataOutputStream(conn.getOutputStream());
//                    dsDataOutputStream.write(imageBytes, 0, imageBytes.length);
//                    dsDataOutputStream.close();

//                    if (conn.getResponseCode() == 200) {
//                        InputStream isInputStream = conn.getInputStream();
//                        int ch;
//                        StringBuffer buffer = new StringBuffer();
//                        while ((ch = isInputStream.read()) != -1) {
//                            buffer.append((char) ch);
//                        }
//                        textView.setText(buffer.toString());
//                        System.out.println(buffer);
//
//                    } else{
//                        System.out.println("无法检测");
//                    }
                    imageView.setImageBitmap(bitmap);
                } catch (Exception e) {
                    e.printStackTrace();
                }
//                } catch (FileNotFoundException e) {
//                    e.printStackTrace();
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }


//        }catch (Exception e){
//
//        }

            }
            textView.setText("亲，麻烦你到分类界面进行搜索来判定这属于那种垃圾哦^-^");
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toMain();
            }
        });
    }

        public void toMain () {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            finish();
        }


    }

